"""장 전 단일가 시장가 주문 거부 재현 점검 (오프라인, NH 서버 호출 없음, 표준 라이브러리만).

python check.py [--output result.json]
evidence/ 의 우리 주문 기록(journal_*.jsonl), 실행 로그(kq150_open_20261124.log),
실제 거래소 시세 기록(exchange_quotes_20261124_0830_0845.jsonl)을 읽어 점검 결과를 낸다.
"""
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
EV = HERE / "evidence"


def rows(name):
    with open(EV / name, encoding="utf-8") as f:
        return [json.loads(x) for x in f if x.strip()]


def summary(name):
    return next(r for r in rows(name) if r.get("name") == "summary")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", default="")
    a = ap.parse_args()
    checks, facts = [], {}

    def check(cid, ok, detail):
        checks.append({"id": cid, "pass": bool(ok), "detail": detail})
        print(f"{'PASS' if ok else 'FAIL'} {cid}: {detail}")

    # 0. 증거 파일 무결성
    files = sorted(p for p in EV.iterdir() if p.is_file())
    facts["sha256"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    check("EVIDENCE_FILES", len(files) == 7, f"{len(files)}/7 파일")

    # 1. 11/24: 08:30:20~08:33:57 시장가 38건 전부 '접수 뒤 거부'
    s = summary("journal_20261124.jsonl")
    tries = json.loads(s["entry_tries"])
    mk = [t for t in tries if t["ord_type"] == "market"]
    rej = [t for t in mk if t["status"] == "rejected_after_ack"]
    facts["market_tries"] = len(mk)
    facts["market_first_last"] = [mk[0]["sent_local"], mk[-1]["sent_local"]]
    check("MARKET_ALL_REJECTED", len(mk) == len(rej) == 38,
          f"시장가 {len(mk)}건 중 거부 {len(rej)}건 ({mk[0]['sent_local'][11:19]}~{mk[-1]['sent_local'][11:19]})")
    acks = [r for r in rows("journal_20261124.jsonl") if r.get("kind") == "order" and r.get("stage") == "ack"]
    check("ACK_WITHOUT_ERROR", all(r.get("reject_code", "") == "" and r.get("msg", "") == "" for r in acks),
          f"주문 응답 {len(acks)}건(신규·취소) 모두 오류코드 없이 접수(주문번호 발급) → 주문내역에서만 거부로 보임")

    # 2. 거부 사유 = 호가접수 개시 전
    log = (EV / "kq150_open_20261124.log").read_text(encoding="utf-8")
    n_reason = log.count("접수 뒤 거부: 호가접수 개시 전")
    check("REJECT_REASON", n_reason == 38, f"주문내역 거부 사유 '호가접수 개시 전' {n_reason}건")

    # 3. 08:34:03 지정가는 바로 정상 접수(미체결 대기)
    lim = [t for t in tries if t["ord_type"] == "limit"]
    hist = [r for r in rows("journal_20261124.jsonl") if r.get("name") == "history"]
    ok3 = lim and lim[0]["status"] == "accepted" and hist and hist[-1]["rows"][0]["status"] == "미체결"
    check("LIMIT_ACCEPTED_0834", ok3, f"지정가 {lim[0]['sent_local'][11:19]} 접수, 주문내역 상태 '{hist[-1]['rows'][0]['status']}' (접수시각 {hist[-1]['rows'][0]['recv_time']})")

    # 4. 실제 거래소는 08:30:00 부터 장 전 호가·예상체결가가 있었다
    q = rows("exchange_quotes_20261124_0830_0845.jsonl")
    pre = [r for r in q if r["t"][11:19] < "08:34:00" and r.get("api") == "KB"]
    est = [r for r in pre if r.get("est_exec_pric")]
    facts["exchange_first_quote"] = pre[0]["t"] if pre else None
    facts["exchange_first_est"] = est[0]["t"] if est else None
    check("EXCHANGE_PREOPEN_LIVE", pre and pre[0]["t"][11:16] == "08:30" and len(est) > 0,
          f"08:30~08:34 실제 호가 {len(pre)}건, 첫 호가 {pre[0]['t'][11:23]}, 첫 예상체결가 {est[0]['t'][11:23]} ({est[0]['est_exec_pric']})")

    # 5. 다른 날 같은 08:30:20 시장가: 11/12·16·18 정상, 11/13 같은 거부
    other = {}
    for d in ("20261112", "20261113", "20261116", "20261118"):
        sd = summary(f"journal_{d}.jsonl")
        t0 = json.loads(sd["entry_tries"])[0]
        hist_d = [r for r in rows(f"journal_{d}.jsonl") if r.get("name") == "history"]
        st = hist_d[0]["rows"][0]["status"] if hist_d else ""
        rs = hist_d[0]["rows"][0].get("reject", "") if hist_d else ""
        other[d] = {"sent": t0["sent_local"][11:19], "history_status": st, "reject": rs,
                    "recv_time": sd.get("entry_recv_time"), "exec_time": sd.get("entry_exec_time"),
                    "mock_fill": sd.get("entry_fill"), "real_open_0845": sd.get("first_open")}
    facts["other_days"] = other
    ok_days = [d for d, v in other.items() if v["history_status"] == "체결"]
    rej_days = [d for d, v in other.items() if v["reject"] == "호가접수 개시 전"]
    check("OTHER_DAYS", ok_days == ["20261112", "20261116", "20261118"] and rej_days == ["20261113"],
          f"같은 08:30:20 시장가: 정상 {ok_days}, 같은 거부 {rej_days}")

    # 6. (참고) 정상 접수된 날 모의 체결 시각·가격 = 08:30:20 즉시, 실제 08:45 시가와 다름
    gaps = {d: f"모의 {v['exec_time']} {float(v['mock_fill']):.1f} vs 실제 08:45 시가 {float(v['real_open_0845']):.1f}"
            for d, v in other.items() if v["mock_fill"]}
    check("MOCK_FILLS_BEFORE_AUCTION", len(gaps) == 3, "; ".join(f"{d} {g}" for d, g in gaps.items()))

    bug = all(c["pass"] for c in checks if c["id"] in ("MARKET_ALL_REJECTED", "REJECT_REASON", "EXCHANGE_PREOPEN_LIVE"))
    print(f"[{'BUG REPRODUCED' if bug else 'NOT REPRODUCED'}] 장 전 단일가 시간(08:30~)에 모의 시장가 주문이 '호가접수 개시 전'으로 거부")
    print(f"검사 {sum(c['pass'] for c in checks)}/{len(checks)} 통과")
    if a.output:
        Path(a.output).write_text(json.dumps({"bug_reproduced": bug, "checks": checks, "facts": facts},
                                             ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
