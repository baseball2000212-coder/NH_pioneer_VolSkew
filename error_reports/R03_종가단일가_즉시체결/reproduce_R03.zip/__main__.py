"""python -B reproduce_R03.zip --output R03_result.json — 압축을 풀지 않고 실행."""
import os
import runpy
import sys
import tempfile
import zipfile

with tempfile.TemporaryDirectory() as d:
    zipfile.ZipFile(sys.argv[0]).extractall(d)
    script = os.path.join(d, "check.py")
    sys.argv = [script] + sys.argv[1:]
    runpy.run_path(script, run_name="__main__")
