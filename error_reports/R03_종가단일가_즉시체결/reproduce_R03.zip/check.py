"""장 마감 단일가(15:35~15:45) 모의 시장가 주문 즉시 체결 재현 점검 (오프라인, NH 서버 호출 없음, 표준 라이브러리만).

python check.py [--output result.json]
evidence/ 의 우리 주문 기록(order_1535_*.jsonl: 15:35:30 청산 주문의 보냄·응답·주문내역)과
같은 날 실제 거래소 체결 기록(exchange_ka_*_1534_1546.jsonl, 실시간 체결 KA)을 읽어 점검 결과를 낸다.
"""
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
EV = HERE / "evidence"
DAYS = ["20261109", "20261112", "20261113", "20261117", "20261118", "20261123", "20261125", "20261126"]


def rows(name):
    with open(EV / name, encoding="utf-8") as f:
        return [json.loads(x) for x in f if x.strip()]


def hms(s):
    s = s.ljust(9, "0")
    return f"{s[:2]}:{s[2:4]}:{s[4:6]}.{s[6:9]}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", default="")
    a = ap.parse_args()
    checks, facts = [], {"days": {}}

    def check(cid, ok, detail):
        checks.append({"id": cid, "pass": bool(ok), "detail": detail})
        print(f"{'PASS' if ok else 'FAIL'} {cid}: {detail}")

    files = sorted(p for p in EV.iterdir() if p.is_file())
    facts["sha256"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    check("EVIDENCE_FILES", len(files) == 2 * len(DAYS), f"{len(files)}/{2 * len(DAYS)} 파일")

    early, live_gap, auction, differs, diffs = [], [], [], [], []
    for d in DAYS:
        o = rows(f"order_1535_{d}.jsonl")
        sent = next(r for r in o if r.get("kind") == "order" and r.get("stage") == "sent")
        hist = next(r for r in o if r.get("name") == "order_history_rows")["rows"][0]
        side = 1 if sent["side"] == "buy" else -1
        px = float(hist["exec_price"])
        k = rows(f"exchange_ka_{d}_1534_1546.jsonl")
        traded = [r for r in k if r.get("exec_qty") not in (None, "", "0")]
        mid = [r for r in traded if "15:35:30" <= r["t"][11:23] < "15:45:00"]
        close = [r for r in traded if r["t"][11:23] >= "15:45:00"]
        c = close[0] if close else None
        facts["days"][d] = {
            "side": sent["side"], "qty": sent["qty"], "sent": sent["ts"][11:23],
            "mock_recv": hms(hist["recv_time"]), "mock_exec": hms(hist["exec_time"]), "mock_price": px,
            "exchange_trades_1535_30_to_1545": len(mid),
            "exchange_close_time": c["t"][11:23] if c else None, "exchange_close_price": float(c["last_pric"]) if c else None,
            "exchange_close_qty": int(c["exec_qty"]) if c else None,
        }
        early.append(hist["exec_time"] < "154500000")
        live_gap.append(len(mid) == 0)
        auction.append(c is not None and c["t"][11:16] == "15:45" and int(c["exec_qty"]) >= 1000)
        if c is not None:
            diff = round(px - float(c["last_pric"]), 2)
            diffs.append(abs(diff))
            differs.append(diff != 0)
            facts["days"][d]["mock_minus_close_pt"] = diff
            facts["days"][d]["against_us_pt"] = round(side * diff, 2)

    f = facts["days"]
    check("MOCK_FILLED_BEFORE_1545", all(early),
          "모의 체결 시각 " + ", ".join(f"{d[4:6]}/{d[6:]} {f[d]['mock_exec']}" for d in DAYS) + ", 모두 15:45 전")
    check("EXCHANGE_NO_TRADES_1535_1545", all(live_gap),
          "실제 거래소 15:35:30~15:44:59 체결 " + ", ".join(f"{d[4:6]}/{d[6:]} {f[d]['exchange_trades_1535_30_to_1545']}건" for d in DAYS))
    check("EXCHANGE_CLOSE_AUCTION_1545", all(auction),
          "실제 15:45 단일가 체결 " + ", ".join(f"{d[4:6]}/{d[6:]} {f[d]['exchange_close_time']} {f[d]['exchange_close_qty']:,}계약 @{f[d]['exchange_close_price']}" for d in DAYS))
    check("MOCK_PRICE_NOT_CLOSE", sum(differs) >= len(DAYS) - 1,
          f"모의 체결가 ≠ 실제 15:45 종가 {sum(differs)}/{len(DAYS)}일, 차이 절댓값 평균 {sum(diffs) / len(diffs):.2f}pt, 최대 {max(diffs):.1f}pt")
    ok = all(c["pass"] for c in checks)
    print("[BUG REPRODUCED] 장 마감 단일가 시간(15:35~15:45)에 낸 모의 시장가 주문이 15:45 종가를 기다리지 않고 접수 순간 다른 가격으로 체결" if ok else "[NOT REPRODUCED]")
    if a.output:
        Path(a.output).write_text(json.dumps({"bug_reproduced": ok, "checks": checks, "facts": facts}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
