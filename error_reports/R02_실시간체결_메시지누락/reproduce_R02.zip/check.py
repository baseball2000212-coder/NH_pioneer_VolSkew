"""실시간 체결(KA) 메시지 누락 재현 점검 (오프라인, NH 서버 호출 없음, 표준 라이브러리만).

python check.py [--output result.json]
evidence/ 의 우리 실시간 체결 기록(ka_A066C000_<날짜>.csv.gz: 받은 순서 그대로, 칸 일부),
수신기 프레임 분류 기록(recorder_journal_20261125.jsonl), NH 분봉 조회 거래량(nh_chart_1m_A066C000_<날짜>.csv)을 읽어
'NH 가 체결 메시지를 보내지 않은 체결'이 있는지 점검한다.
"""
import argparse
import bisect
import collections
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
EV = HERE / "evidence"
DAYS = ("20261124", "20261125")


def ka_rows(day):
    """받은 순서 그대로: (수신시각, 거래소시각, tick_div, 누적체결수량, 체결수량, 누적체결건수(매수+매도), 체결가).
    tick_div=1 은 체결 1건마다 오는 메시지, tick_div=0 은 약 1초마다 오는 상태 메시지(체결수량 0 또는 직전 값)."""
    with gzip.open(EV / f"ka_A066C000_{day}.csv.gz", "rt", encoding="utf-8", newline="") as f:
        out = []
        for r in csv.DictReader(f):
            out.append((r["t"], r["exch_tm"], r["tick_div"], int(r["cum_trd_qty"]), int(r["exec_qty"]),
                        int(r["cum_buy_cnt"]) + int(r["cum_sel_cnt"]), r["last_pric"], r["high_pric"], r["low_pric"]))
        return out


def segment(hm):
    """시간대: 시가 단일가 체결(08:45:00) 뒤 ~09:00 / 09:00~15:20 / 15:20~15:35 / 종가 단일가."""
    if hm < "09:00":
        return "08:45~09:00"
    if hm < "15:20":
        return "09:00~15:20"
    if hm < "15:35":
        return "15:20~15:35"
    return "15:35~(종가 단일가)"


def chart(day):
    with open(EV / f"nh_chart_1m_A066C000_{day}.csv", encoding="utf-8") as f:
        return {r["ts"][11:16]: int(r["v"]) for r in csv.DictReader(f)}


def analyse(day):
    rows = ka_rows(day)
    trades = [r for r in rows if r[2] == "1"]
    status = [r for r in rows if r[2] == "0"]
    # 받은 순서에서 체결 메시지의 누적값이 줄어드는 곳(=늦은 체결이 먼저 옴), 우리 수신시각이 줄어드는 곳(=우리 기록 순서 오류)
    cum_back = sum(1 for a, b in zip(trades, trades[1:]) if b[3] < a[3])
    t_back = sum(1 for a, b in zip(rows, rows[1:]) if b[0] < a[0])
    by_cum = {}
    for r in trades:
        by_cum.setdefault(r[3], r)
    dup = len(trades) - len(by_cum)
    cs = sorted(by_cum)
    nh_count = max(r[5] for r in rows)       # NH 가 매 메시지에 싣는 누적 체결 건수의 마지막 값
    nh_cum = max(r[3] for r in rows)         # NH 누적체결수량의 마지막 값
    recv_qty = sum(by_cum[c][4] for c in cs)
    holes, by_hour = [], collections.Counter()
    for a, b in zip(cs, cs[1:]):
        A, B = by_cum[a], by_cum[b]
        dk = B[5] - A[5]
        if dk > 1:
            holes.append({"before": {"t": A[0], "exch_tm": A[1], "cum_qty": a, "cum_cnt": A[5], "price": A[6]},
                          "after": {"t": B[0], "exch_tm": B[1], "cum_qty": b, "cum_cnt": B[5], "exec_qty": B[4], "price": B[6]},
                          "missing_trades": dk - 1, "missing_qty": (b - a) - B[4]})
            by_hour[B[0][11:13]] += dk - 1
    miss_trades = nh_count - len(cs)
    miss_qty = nh_cum - recv_qty
    # 합쳐 보내기(conflation)인가: 빈 자리 뒤 메시지의 체결수량에 빠진 수량이 합쳐져 있으면 missing_qty 가 0 이 된다
    merged = sum(1 for h in holes if h["missing_qty"] <= 0)

    def ms(t):
        return int(t[11:13]) * 3600000 + int(t[14:16]) * 60000 + int(t[17:19]) * 1000 + int(t[20:23])
    gap_iv, norm_iv = [], []
    for a, b in zip(cs, cs[1:]):
        iv = ms(by_cum[b][0]) - ms(by_cum[a][0])
        (gap_iv if by_cum[b][5] - by_cum[a][5] > 1 else norm_iv).append(iv)
    gap_iv.sort()
    norm_iv.sort()
    sizes = collections.Counter(min(h["missing_qty"], 5) for h in holes if h["missing_trades"] == 1)
    # 시간대별: NH 누적 건수 증가 중 체결 메시지가 없는 몫 (빈 자리 뒤 메시지의 수신 시각으로 나눔)
    seg_all, seg_miss = collections.Counter(), collections.Counter()
    for a, b in zip(cs, cs[1:]):
        s = segment(by_cum[b][0][11:19])
        dk = by_cum[b][5] - by_cum[a][5]
        seg_all[s] += dk
        seg_miss[s] += max(dk - 1, 0)
    seg = {s: {"nh_trades": seg_all[s], "missing": seg_miss[s],
               "missing_pct": round(100 * seg_miss[s] / seg_all[s], 2) if seg_all[s] else None}
           for s in ("08:45~09:00", "09:00~15:20", "15:20~15:35", "15:35~(종가 단일가)")}
    # 같은 KA 연결의 상태 메시지(tick_div=0)가, 체결 메시지로는 한 번도 오지 않은 누적 건수 값을 싣고 온 경우
    trade_cnts = {by_cum[c][5] for c in cs}
    cnt_sorted = sorted((by_cum[c][5], c, by_cum[c][4]) for c in cs)
    keys = [x[0] for x in cnt_sorted]
    reveal, reveal_ok = set(), 0
    for r in status:
        k = r[5]
        if k in trade_cnts or k in reveal or k <= keys[0] or k >= keys[-1]:
            continue
        i = bisect.bisect_left(keys, k)
        lo, hi = cnt_sorted[i - 1], cnt_sorted[i]
        reveal.add(k)
        # 앞뒤 체결 메시지 사이 빈 자리 안에 있고, 수량도 그 사이에 맞게 들어가 있나
        if hi[0] - lo[0] > 1 and lo[1] < r[3] <= hi[1] - hi[2]:
            reveal_ok += 1
    # 일중 고가·저가: 체결 순서(누적 건수 순)로 볼 때 고가(저가)가 새로 바뀌었는데, 그것을 처음 보여 준 체결 메시지의
    # 체결가가 새 고가(저가)가 아니고 바로 앞 체결 메시지와의 사이에 건수가 빈 경우 = 새 고가를 만든 체결의 메시지가 없음
    high_wo, low_wo, n_high, n_low = [], [], 0, 0
    prev = None
    for c in cs:
        r = by_cum[c]
        if prev is not None and r[7] and prev[7] and float(r[7]) > float(prev[7]):
            n_high += 1
            if r[6] != r[7] and r[5] - prev[5] > 1:
                high_wo.append({"t": r[0][11:23], "high_before": prev[7], "high_after": r[7], "msg_price": r[6],
                                "cnt_before": prev[5], "cnt_after": r[5]})
        if prev is not None and r[8] and prev[8] and float(r[8]) < float(prev[8]):
            n_low += 1
            if r[6] != r[8] and r[5] - prev[5] > 1:
                low_wo.append({"t": r[0][11:23], "low_before": prev[8], "low_after": r[8], "msg_price": r[6],
                               "cnt_before": prev[5], "cnt_after": r[5]})
        prev = r
    ch = chart(day)
    # 분별 비교: 받은 체결 메시지 수량 합 vs NH 분봉 거래량
    per_min = collections.Counter()
    for c in cs:
        per_min[by_cum[c][0][11:16]] += by_cum[c][4]
    mins = [(k, per_min.get(k, 0), v) for k, v in sorted(ch.items())]
    return {
        "messages": len(rows), "trade_messages": len(trades), "status_messages": len(status),
        "trade_messages_duplicated": dup,
        "nh_cum_trade_count": nh_count, "missing_trades": miss_trades,
        "missing_trades_pct": round(100 * miss_trades / nh_count, 2),
        "count_jumps": len(holes), "count_jumps_missing_trades": sum(h["missing_trades"] for h in holes),
        "nh_cum_qty": nh_cum, "received_qty": recv_qty, "missing_qty": miss_qty,
        "missing_qty_pct": round(100 * miss_qty / nh_cum, 2),
        "chart_total_qty": sum(ch.values()),
        "minutes_compared": len(mins),
        "minutes_messages_short_of_chart": sum(1 for m in mins if m[1] < m[2]),
        "minutes_messages_over_chart": sum(1 for m in mins if m[1] > m[2]),
        "trade_cum_reversed_in_arrival": cum_back, "recv_time_reversed": t_back,
        "missing_trades_by_hour": dict(sorted(by_hour.items())),
        "missing_by_segment": seg,
        "holes_qty_merged_into_next": merged,
        "recv_interval_ms_median_across_hole": gap_iv[len(gap_iv) // 2] if gap_iv else None,
        "recv_interval_ms_median_normal": norm_iv[len(norm_iv) // 2] if norm_iv else None,
        "single_missing_trade_qty_dist_5plus": dict(sorted(sizes.items())),
        "avg_qty_missing_trade": round(miss_qty / miss_trades, 2) if miss_trades else None,
        "avg_qty_received_trade": round(recv_qty / len(cs), 2),
        "status_msgs_revealing_missing_counts": len(reveal), "status_reveal_inside_hole_and_qty_fits": reveal_ok,
        "new_highs": n_high, "new_highs_without_trade_message": high_wo,
        "new_lows": n_low, "new_lows_without_trade_message": low_wo,
        "hole_examples": holes[:5],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", default="")
    a = ap.parse_args()
    checks, facts = [], {}

    def check(cid, ok, detail):
        checks.append({"id": cid, "pass": bool(ok), "detail": detail})
        print(f"{'PASS' if ok else 'FAIL'} {cid}: {detail}")

    # 0. 증거 파일 무결성
    files = sorted(p for p in EV.iterdir() if p.is_file())
    facts["sha256"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    check("EVIDENCE_FILES", len(files) == 5, f"{len(files)}/5 파일")

    # 1. 우리 수신기는 11/25 받은 프레임을 하나도 버리지 않았다
    j = [json.loads(x) for x in (EV / "recorder_journal_20261125.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
    wf = [r for r in j if r.get("name") == "ws_frames"][-1]
    fr = wf["frames"]
    facts["ws_frames_20261125"] = {"frames": fr, "drop_samples": wf.get("drop_samples"), "ts": wf["ts"]}
    check("RECEIVER_NO_DROP", fr.get("delivered", 0) > 0 and fr.get("unparsed", 0) == 0
          and fr.get("dropped_shape", 0) == 0 and not wf.get("drop_samples"),
          f"11/25 받은 프레임 {fr.get('delivered', 0) + fr.get('control', 0):,}개 = 시세 {fr.get('delivered', 0):,} + 제어 {fr.get('control', 0):,}, "
          f"해석 실패 {fr.get('unparsed', 0)} · 모양 불일치 {fr.get('dropped_shape', 0)} (세 종목 합계)")

    res = {d: analyse(d) for d in DAYS}
    facts["days"] = res
    r = res["20261125"]

    # 2. NH 자신의 누적 체결 건수가 받은 체결 메시지 수보다 많다 (체결 메시지는 중복 0)
    check("NH_COUNT_GAP", r["missing_trades"] > 0 and r["trade_messages_duplicated"] == 0,
          f"11/25 A066C000 NH 누적 체결 건수(cum_buy_cnt+cum_sel_cnt) {r['nh_cum_trade_count']:,}건 vs 받은 체결 메시지(tick_div=1) "
          f"{r['trade_messages']:,}건(중복 {r['trade_messages_duplicated']}) → 메시지 없는 체결 {r['missing_trades']:,}건 ({r['missing_trades_pct']}%), "
          f"건수가 2 이상 건너뛴 자리 {r['count_jumps']:,}곳")

    # 2b. 같은 KA 연결의 상태 메시지가 '체결 메시지로 오지 않은 체결'의 누적 건수·수량을 싣고 왔다 (NH 메시지끼리 모순)
    check("STATUS_MSG_SHOWS_MISSING", r["status_reveal_inside_hole_and_qty_fits"] > 0,
          f"11/25 상태 메시지(tick_div=0)가 체결 메시지로는 한 번도 오지 않은 누적 건수 값을 실은 경우 "
          f"{r['status_msgs_revealing_missing_counts']:,}개, 그중 앞뒤 체결 메시지 사이 빈 자리에 건수·수량이 맞게 들어가는 것 "
          f"{r['status_reveal_inside_hole_and_qty_fits']:,}개")

    # 2c. 일중 고가·저가가 바뀌었는데 그 가격의 체결 메시지가 없다 (빠진 것은 호가창의 일반 체결)
    hw, lw = r["new_highs_without_trade_message"], r["new_lows_without_trade_message"]
    ex = (hw + lw)[:1]
    ex_txt = (f" 예: {ex[0]['t']} 고가 {ex[0].get('high_before')}→{ex[0].get('high_after')} 인데 그 메시지 체결가 {ex[0]['msg_price']}, "
              f"건수 {ex[0]['cnt_before']}→{ex[0]['cnt_after']}") if ex and "high_before" in ex[0] else (
              f" 예: {ex[0]['t']} 저가 {ex[0]['low_before']}→{ex[0]['low_after']} 인데 그 메시지 체결가 {ex[0]['msg_price']}" if ex else "")
    check("NEW_HIGH_LOW_WITHOUT_TRADE", len(hw) + len(lw) > 0,
          f"11/25 일중 고가 갱신 {r['new_highs']}번 중 갱신 체결의 메시지가 없는 것 {len(hw)}번, 저가 갱신 {r['new_lows']}번 중 {len(lw)}번.{ex_txt}")

    # 2d. 시간대별 (참고)
    sg = r["missing_by_segment"]
    check("BY_SEGMENT", sg["09:00~15:20"]["missing"] > 0,
          "11/25 시간대별 메시지 없는 체결: " + ", ".join(f"{k} {v['missing']:,}/{v['nh_trades']:,}건({v['missing_pct']}%)" for k, v in sg.items()))

    # 3. 수량도 같은 만큼 빈다: 누적체결수량 − 받은 체결수량 합
    check("NH_VOLUME_GAP", r["missing_qty"] > 0,
          f"11/25 누적체결수량 {r['nh_cum_qty']:,}계약 vs 받은 체결수량 합 {r['received_qty']:,}계약 → "
          f"{r['missing_qty']:,}계약 ({r['missing_qty_pct']}%) 메시지 없음")

    # 4. (보조) NH 분봉 조회 거래량 합 = 실시간 누적체결수량 — 같은 NH 장부라 독립 증거는 아니고 NH 내부 정합성만 보임
    check("CHART_EQUALS_CUM", r["chart_total_qty"] == r["nh_cum_qty"],
          f"11/25 NH 분봉 거래량 합 {r['chart_total_qty']:,} = 실시간 누적체결수량 {r['nh_cum_qty']:,}; "
          f"{r['minutes_compared']}분 중 {r['minutes_messages_short_of_chart']}분은 받은 체결 메시지 수량 합이 분봉 거래량보다 적고, "
          f"많은 분은 {r['minutes_messages_over_chart']}분")

    # 5. 전날(11/24)도 같다
    p = res["20261124"]
    check("SAME_ON_20261124", p["missing_trades"] > 0 and p["chart_total_qty"] == p["nh_cum_qty"],
          f"11/24 메시지 없는 체결 {p['missing_trades']:,}건 ({p['missing_trades_pct']}%), {p['missing_qty']:,}계약 ({p['missing_qty_pct']}%), "
          f"분봉 합 {p['chart_total_qty']:,} = 누적 {p['nh_cum_qty']:,}")

    # 6. (참고) 받은 순서에서 누적값이 거꾸로 가는 곳 — 수신시각은 한 번도 거꾸로 가지 않음
    check("ARRIVAL_ORDER_REVERSED", r["trade_cum_reversed_in_arrival"] > 0 and r["recv_time_reversed"] == 0,
          f"11/25 체결 메시지 중 늦은 체결이 먼저 도착 {r['trade_cum_reversed_in_arrival']}번 (11/24 {p['trade_cum_reversed_in_arrival']}번), "
          f"우리 수신시각 역전 {r['recv_time_reversed']}번")

    bug = all(c["pass"] for c in checks if c["id"] in ("RECEIVER_NO_DROP", "NH_COUNT_GAP", "STATUS_MSG_SHOWS_MISSING", "NH_VOLUME_GAP"))
    print(f"[{'BUG REPRODUCED' if bug else 'NOT REPRODUCED'}] 실시간 체결(KA)에서 약 2% 체결의 메시지가 오지 않음 (누적값에는 반영)")
    print(f"검사 {sum(c['pass'] for c in checks)}/{len(checks)} 통과")
    if a.output:
        Path(a.output).write_text(json.dumps({"bug_reproduced": bug, "checks": checks, "facts": facts},
                                             ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
